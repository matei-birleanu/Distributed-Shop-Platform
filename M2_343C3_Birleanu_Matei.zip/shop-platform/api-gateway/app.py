from flask import Flask, request, jsonify, render_template_string, redirect, session
from functools import wraps
import requests
import jwt
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')

KEYCLOAK_URL = os.environ.get('KEYCLOAK_URL', 'http://keycloak:8080')
PRODUCT_SERVICE_URL = os.environ.get('PRODUCT_SERVICE_URL', 'http://product-service:5001')
ORDER_SERVICE_URL = os.environ.get('ORDER_SERVICE_URL', 'http://order-service:5002')

# config keycloak
KEYCLOAK_REALM = os.environ.get('KEYCLOAK_REALM', 'shop-platform')
KEYCLOAK_CLIENT_ID = os.environ.get('KEYCLOAK_CLIENT_ID', 'shop-client')
KEYCLOAK_CLIENT_SECRET = os.environ.get('KEYCLOAK_CLIENT_SECRET', 'shop-client-secret')

def get_keycloak_public_key():
    try:
        url = f"{KEYCLOAK_URL}/realms/{KEYCLOAK_REALM}"
        response = requests.get(url, timeout=5)
        key_data = response.json()
        return key_data.get('public_key')
    except Exception as e:
        app.logger.error(f"Error fetching Keycloak public key: {e}")
        return None

def verify_token(token):
    try:
        public_key = get_keycloak_public_key()
        if not public_key:
            return None
        
        # format public key for pyjwt
        public_key_formatted = f"-----BEGIN PUBLIC KEY-----\n{public_key}\n-----END PUBLIC KEY-----"
        
        decoded = jwt.decode(
            token,
            public_key_formatted,
            algorithms=['RS256'],
            options={
                'verify_exp': True,
                'verify_aud': False,
                'verify_iss': False,
                'require': ['exp', 'iat', 'sub']
            }
        )
        
        expected_iss = f"{KEYCLOAK_URL}/realms/{KEYCLOAK_REALM}"
        if decoded.get('iss') != expected_iss:
            app.logger.warning(f"Issuer mismatch: {decoded.get('iss')} != {expected_iss}")
        
        return decoded
    except jwt.ExpiredSignatureError:
        app.logger.error("Token expired")
        return None
    except Exception as e:
        app.logger.error(f"Token verification error: {e}")
        return None

def get_user_roles(token_data):
    if not token_data:
        return ['visitor']
    
    roles = []
    if 'realm_access' in token_data and 'roles' in token_data['realm_access']:
        roles.extend(token_data['realm_access']['roles'])
    
    if 'resource_access' in token_data and KEYCLOAK_CLIENT_ID in token_data['resource_access']:
        client_roles = token_data['resource_access'][KEYCLOAK_CLIENT_ID].get('roles', [])
        roles.extend(client_roles)
    
    if not roles or all(role in ['offline_access', 'uma_authorization'] for role in roles):
        roles.append('visitor')
    
    return roles

def require_auth(required_roles=None):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            token = None
            
            # get token
            auth_header = request.headers.get('Authorization')
            if auth_header and auth_header.startswith('Bearer '):
                token = auth_header.split(' ')[1]
            
            # get toke from sess
            if not token:
                token = session.get('access_token')
            
            if not token:
                return jsonify({'error': 'No token provided', 'message': 'Authentication required'}), 401
            
            token_data = verify_token(token)
            if not token_data:
                return jsonify({'error': 'Invalid token', 'message': 'Authentication failed'}), 401
            
            # check roles
            user_roles = get_user_roles(token_data)
            if required_roles:
                if not any(role in user_roles for role in required_roles):
                    return jsonify({
                        'error': 'Insufficient permissions',
                        'message': f'Requires one of: {required_roles}',
                        'your_roles': user_roles
                    }), 403
            
            # add user info
            request.user_info = {
                'user_id': token_data.get('sub'),
                'username': token_data.get('preferred_username'),
                'email': token_data.get('email'),
                'roles': user_roles
            }
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator


@app.route('/')
def home():
    return jsonify({
        'message': 'Online Shopping Platform API',
        'version': '1.0',
        'endpoints': {
            'auth': '/auth/login, /auth/logout, /auth/me',
            'products': '/products, /products/{id}, /products/search',
            'orders': '/orders, /orders/{id}',
            'admin': '/admin/products, /admin/orders, /admin/users'
        }
    })

@app.route('/auth/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    
    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400
    
    # toke from keycloak
    token_url = f"{KEYCLOAK_URL}/realms/{KEYCLOAK_REALM}/protocol/openid-connect/token"
    payload = {
        'client_id': KEYCLOAK_CLIENT_ID,
        'client_secret': KEYCLOAK_CLIENT_SECRET,
        'grant_type': 'password',
        'username': username,
        'password': password
    }
    
    try:
        response = requests.post(token_url, data=payload, timeout=5)
        if response.status_code == 200:
            token_data = response.json()
            
            session['access_token'] = token_data['access_token']
            session['refresh_token'] = token_data.get('refresh_token')
            
            return jsonify({
                'message': 'Login successful',
                'access_token': token_data['access_token'],
                'refresh_token': token_data.get('refresh_token'),
                'expires_in': token_data.get('expires_in')
            })
        else:
            return jsonify({'error': 'Invalid credentials'}), 401
    except Exception as e:
        app.logger.error(f"Login error: {e}")
        return jsonify({'error': 'Authentication service unavailable'}), 503

@app.route('/auth/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'message': 'Logged out successfully'})

@app.route('/auth/me')
@require_auth()
def me():
    return jsonify(request.user_info)


@app.route('/products', methods=['GET'])
def get_products():
    try:
        response = requests.get(f"{PRODUCT_SERVICE_URL}/products", timeout=5)
        return jsonify(response.json()), response.status_code
    except Exception as e:
        app.logger.error(f"Error fetching products: {e}")
        return jsonify({'error': 'Product service unavailable'}), 503

@app.route('/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    try:
        response = requests.get(f"{PRODUCT_SERVICE_URL}/products/{product_id}", timeout=5)
        return jsonify(response.json()), response.status_code
    except Exception as e:
        app.logger.error(f"Error fetching product: {e}")
        return jsonify({'error': 'Product service unavailable'}), 503

@app.route('/products/search', methods=['GET'])
def search_products():
    query = request.args.get('query', '')
    category = request.args.get('category', '')
    min_price = request.args.get('minPrice', '')
    max_price = request.args.get('maxPrice', '')
    
    params = {
        'query': query,
        'category': category,
        'minPrice': min_price,
        'maxPrice': max_price
    }
    
    try:
        response = requests.get(f"{PRODUCT_SERVICE_URL}/products/search", params=params, timeout=5)
        return jsonify(response.json()), response.status_code
    except Exception as e:
        app.logger.error(f"Error searching products: {e}")
        return jsonify({'error': 'Product service unavailable'}), 503


@app.route('/admin/products', methods=['POST'])
@require_auth(required_roles=['admin'])
def create_product():
    try:
        response = requests.post(
            f"{PRODUCT_SERVICE_URL}/products",
            json=request.get_json(),
            timeout=5
        )
        return jsonify(response.json()), response.status_code
    except Exception as e:
        app.logger.error(f"Error creating product: {e}")
        return jsonify({'error': 'Product service unavailable'}), 503

@app.route('/admin/products/<int:product_id>/price', methods=['PUT'])
@require_auth(required_roles=['admin'])
def update_price(product_id):
    try:
        response = requests.put(
            f"{PRODUCT_SERVICE_URL}/products/{product_id}/price",
            json=request.get_json(),
            timeout=5
        )
        return jsonify(response.json()), response.status_code
    except Exception as e:
        app.logger.error(f"Error updating price: {e}")
        return jsonify({'error': 'Product service unavailable'}), 503

@app.route('/admin/products/<int:product_id>/stock', methods=['PUT'])
@require_auth(required_roles=['admin'])
def update_stock(product_id):
    try:
        response = requests.put(
            f"{PRODUCT_SERVICE_URL}/products/{product_id}/stock",
            json=request.get_json(),
            timeout=5
        )
        return jsonify(response.json()), response.status_code
    except Exception as e:
        app.logger.error(f"Error updating stock: {e}")
        return jsonify({'error': 'Product service unavailable'}), 503

@app.route('/admin/products/<int:product_id>', methods=['DELETE'])
@require_auth(required_roles=['admin'])
def delete_product(product_id):
    try:
        response = requests.delete(f"{PRODUCT_SERVICE_URL}/products/{product_id}", timeout=5)
        return jsonify(response.json()), response.status_code
    except Exception as e:
        app.logger.error(f"Error deleting product: {e}")
        return jsonify({'error': 'Product service unavailable'}), 503


@app.route('/orders', methods=['GET', 'POST'])
@require_auth()
def orders():
    try:
        headers = {'X-User-Info': str(request.user_info)}
        
        if request.method == 'GET':
            if 'admin' in request.user_info['roles']:
                params = request.args.to_dict()
                response = requests.get(f"{ORDER_SERVICE_URL}/orders", params=params, headers=headers, timeout=5)
            else:
                response = requests.get(f"{ORDER_SERVICE_URL}/orders/user/{request.user_info['user_id']}", headers=headers, timeout=5)
        else: 
            response = requests.post(
                f"{ORDER_SERVICE_URL}/orders",
                json=request.get_json(),
                headers=headers,
                timeout=5
            )
        
        return jsonify(response.json()), response.status_code
    except Exception as e:
        app.logger.error(f"Error with orders: {e}")
        return jsonify({'error': 'Order service unavailable'}), 503

@app.route('/orders/<int:order_id>', methods=['GET'])
@require_auth()
def get_order(order_id):
    try:
        headers = {'X-User-Info': str(request.user_info)}
        response = requests.get(f"{ORDER_SERVICE_URL}/orders/{order_id}", headers=headers, timeout=5)
        return jsonify(response.json()), response.status_code
    except Exception as e:
        app.logger.error(f"Error fetching order: {e}")
        return jsonify({'error': 'Order service unavailable'}), 503

@app.route('/sell', methods=['POST'])
@require_auth()
def sell_product():
    try:
        headers = {'X-User-Info': str(request.user_info)}
        response = requests.post(
            f"{ORDER_SERVICE_URL}/sell",
            json=request.get_json(),
            headers=headers,
            timeout=5
        )
        return jsonify(response.json()), response.status_code
    except Exception as e:
        app.logger.error(f"Error selling product: {e}")
        return jsonify({'error': 'Order service unavailable'}), 503

@app.route('/health')
def health():
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'service': 'api-gateway'
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

