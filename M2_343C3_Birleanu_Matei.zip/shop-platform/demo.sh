#!/bin/bash
echo Script testare
echo Vizualizare servicii
curl -s http://localhost:5000/ | python3 -m json.tool

echo Logare si salvare token
ADMIN_TOKEN=$(curl -s -X POST http://localhost:5000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}' | jq -r '.access_token')

echo Creez produs
curl -s -X POST http://localhost:5000/admin/products \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "iPhone 17 Pro",
    "description": "teapa de telefon",
    "price": 66666,
    "stock": 69,
    "category": "electronice"
  }' | python3 -m json.tool

echo Vizualizez produsele
curl -s http://localhost:5000/products | python3 -m json.tool

echo Cauta telefon 

curl -s "http://localhost:5000/products/search?query=telefon" | python3 -m json.tool

echo Logare ca user
USER_TOKEN=$(curl -s -X POST http://localhost:5000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"user","password":"user123"}' | jq -r '.access_token')
echo $USER_TOKEN

echo verific stoc iphone 
curl -s http://localhost:5000/products/5| python3 -m json.tool

echo Cumpar 2 Iphone-uri
curl -s -X POST http://localhost:5000/orders \
  -H "Authorization: Bearer $USER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"product_id":5,"quantity":2}' | python3 -m json.tool

echo verific stoc iphone 
curl -s http://localhost:5000/products/1 | python3 -m json.tool

echo vand un iphone
curl -s -X POST http://localhost:5000/sell \
  -H "Authorization: Bearer $USER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"product_id":5,"quantity":1}' | python3 -m json.tool

echo verific stoc iphone 
curl -s http://localhost:5000/products/5 | python3 -m json.tool

echo vad comenzi
curl -s http://localhost:5000/orders \
  -H "Authorization: Bearer $USER_TOKEN" | python3 -m json.tool






