from flask import Flask, request, jsonify
from sqlalchemy import create_engine, Column, Integer, String, Float, Text, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, scoped_session
from datetime import datetime
import os

app = Flask(__name__)

DATABASE_URL = os.environ.get(
    'DATABASE_URL',
    'postgresql://shop_user:shop_password@database:5432/shop_db'
)

engine = create_engine(DATABASE_URL, pool_pre_ping=True, pool_size=10, max_overflow=20)
SessionLocal = scoped_session(sessionmaker(bind=engine))
Base = declarative_base()

class Product(Base):
    __tablename__ = 'products'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    price = Column(Float, nullable=False)
    stock = Column(Integer, default=0)
    category = Column(String(100))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'price': self.price,
            'stock': self.stock,
            'category': self.category,
            'in_stock': self.stock > 0,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

Base.metadata.create_all(engine)

def get_db():
    db = SessionLocal()
    try:
        return db
    finally:
        pass 

@app.teardown_appcontext
def remove_session(exception=None):
    SessionLocal.remove()

@app.route('/products', methods=['GET'])
def get_products():
    db = get_db()
    try:
        products = db.query(Product).all()
        return jsonify({
            'products': [p.to_dict() for p in products],
            'count': len(products)
        })
    except Exception as e:
        app.logger.error(f"Error fetching products: {e}")
        return jsonify({'error': 'Database error'}), 500

@app.route('/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    db = get_db()
    try:
        product = db.query(Product).filter(Product.id == product_id).first()
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        return jsonify(product.to_dict())
    except Exception as e:
        app.logger.error(f"Error fetching product: {e}")
        return jsonify({'error': 'Database error'}), 500

@app.route('/products/search', methods=['GET'])
def search_products():
    db = get_db()
    try:
        query_text = request.args.get('query', '')
        category = request.args.get('category', '')
        min_price = request.args.get('minPrice', type=float)
        max_price = request.args.get('maxPrice', type=float)
        
        query = db.query(Product)
        
        if query_text:
            search_pattern = f"%{query_text}%"
            query = query.filter(
                (Product.name.ilike(search_pattern)) |
                (Product.description.ilike(search_pattern))
            )
        
        if category:
            query = query.filter(Product.category == category)
        
        if min_price is not None:
            query = query.filter(Product.price >= min_price)
        if max_price is not None:
            query = query.filter(Product.price <= max_price)
        
        products = query.all()
        
        return jsonify({
            'products': [p.to_dict() for p in products],
            'count': len(products),
            'filters': {
                'query': query_text,
                'category': category,
                'minPrice': min_price,
                'maxPrice': max_price
            }
        })
    except Exception as e:
        app.logger.error(f"Error searching products: {e}")
        return jsonify({'error': 'Database error'}), 500

@app.route('/products', methods=['POST'])
def create_product():
    db = get_db()
    try:
        data = request.get_json()
        
        required_fields = ['name', 'price']
        if not all(field in data for field in required_fields):
            return jsonify({'error': 'Missing required fields: name, price'}), 400
        
        product = Product(
            name=data['name'],
            description=data.get('description', ''),
            price=float(data['price']),
            stock=int(data.get('stock', 0)),
            category=data.get('category', 'general')
        )
        
        db.add(product)
        db.commit()
        db.refresh(product)
        
        return jsonify({
            'message': 'Product created successfully',
            'product': product.to_dict()
        }), 201
    except Exception as e:
        db.rollback()
        app.logger.error(f"Error creating product: {e}")
        return jsonify({'error': 'Failed to create product'}), 500

@app.route('/products/<int:product_id>/price', methods=['PUT'])
def update_price(product_id):
    db = get_db()
    try:
        data = request.get_json()
        
        if 'price' not in data:
            return jsonify({'error': 'Price is required'}), 400
        
        product = db.query(Product).filter(Product.id == product_id).first()
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        old_price = product.price
        product.price = float(data['price'])
        product.updated_at = datetime.utcnow()
        
        db.commit()
        db.refresh(product)
        
        return jsonify({
            'message': 'Price updated successfully',
            'product': product.to_dict(),
            'old_price': old_price
        })
    except Exception as e:
        db.rollback()
        app.logger.error(f"Error updating price: {e}")
        return jsonify({'error': 'Failed to update price'}), 500

@app.route('/products/<int:product_id>/stock', methods=['PUT'])
def update_stock(product_id):
    db = get_db()
    try:
        data = request.get_json()
        
        if 'quantity' not in data:
            return jsonify({'error': 'Quantity is required'}), 400
        
        product = db.query(Product).filter(Product.id == product_id).first()
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        old_stock = product.stock
        product.stock = int(data['quantity'])
        product.updated_at = datetime.utcnow()
        
        db.commit()
        db.refresh(product)
        
        return jsonify({
            'message': 'Stock updated successfully',
            'product': product.to_dict(),
            'old_stock': old_stock
        })
    except Exception as e:
        db.rollback()
        app.logger.error(f"Error updating stock: {e}")
        return jsonify({'error': 'Failed to update stock'}), 500

@app.route('/products/<int:product_id>/stock/adjust', methods=['POST'])
def adjust_stock(product_id):
    db = get_db()
    try:
        data = request.get_json()
        
        if 'adjustment' not in data:
            return jsonify({'error': 'Adjustment value is required'}), 400
        
        adjustment = int(data['adjustment'])
        
        product = db.query(Product).filter(Product.id == product_id).first()
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        if adjustment < 0 and product.stock + adjustment < 0:
            return jsonify({
                'error': 'Insufficient stock',
                'available': product.stock,
                'requested': abs(adjustment)
            }), 400
        
        old_stock = product.stock
        product.stock += adjustment
        product.updated_at = datetime.utcnow()
        
        db.commit()
        db.refresh(product)
        
        return jsonify({
            'message': 'Stock adjusted successfully',
            'product': product.to_dict(),
            'old_stock': old_stock,
            'adjustment': adjustment
        })
    except Exception as e:
        db.rollback()
        app.logger.error(f"Error adjusting stock: {e}")
        return jsonify({'error': 'Failed to adjust stock'}), 500

@app.route('/products/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    db = get_db()
    try:
        product = db.query(Product).filter(Product.id == product_id).first()
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        product_data = product.to_dict()
        db.delete(product)
        db.commit()
        
        return jsonify({
            'message': 'Product deleted successfully',
            'product': product_data
        })
    except Exception as e:
        db.rollback()
        app.logger.error(f"Error deleting product: {e}")
        return jsonify({'error': 'Failed to delete product'}), 500

@app.route('/health')
def health():
    db = get_db()
    try:
        db.execute('SELECT 1')
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.utcnow().isoformat(),
            'service': 'product-service',
            'database': 'connected'
        })
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'timestamp': datetime.utcnow().isoformat(),
            'service': 'product-service',
            'database': 'disconnected',
            'error': str(e)
        }), 503

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)

