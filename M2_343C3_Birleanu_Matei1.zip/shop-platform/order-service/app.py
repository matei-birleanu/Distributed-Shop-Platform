
from flask import Flask, request, jsonify
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Enum as SQLEnum
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, scoped_session
from datetime import datetime
from enum import Enum
import os
import requests
import ast

app = Flask(__name__)

DATABASE_URL = os.environ.get(
    'DATABASE_URL',
    'postgresql://shop_user:shop_password@database:5432/shop_db'
)

PRODUCT_SERVICE_URL = os.environ.get('PRODUCT_SERVICE_URL', 'http://product-service:5001')

# sqlalchkemy setup
engine = create_engine(DATABASE_URL, pool_pre_ping=True, pool_size=10, max_overflow=20)
SessionLocal = scoped_session(sessionmaker(bind=engine))
Base = declarative_base()


class OrderType(str, Enum):
    BUY = "buy"
    SELL = "sell"

class OrderStatus(str, Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    FAILED = "failed"


class Order(Base):
    __tablename__ = 'orders'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(String(255), nullable=False)
    username = Column(String(255))
    product_id = Column(Integer, nullable=False)
    product_name = Column(String(255))
    quantity = Column(Integer, nullable=False)
    price_per_unit = Column(Float, nullable=False)
    total_price = Column(Float, nullable=False)
    order_type = Column(SQLEnum(OrderType), default=OrderType.BUY)
    status = Column(SQLEnum(OrderStatus), default=OrderStatus.PENDING)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'username': self.username,
            'product_id': self.product_id,
            'product_name': self.product_name,
            'quantity': self.quantity,
            'price_per_unit': self.price_per_unit,
            'total_price': self.total_price,
            'order_type': self.order_type.value if isinstance(self.order_type, Enum) else self.order_type,
            'status': self.status.value if isinstance(self.status, Enum) else self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

Base.metadata.create_all(engine)


def get_db():
    db = SessionLocal()
    try:
        return db
    finally:
        pass

@app.teardown_appcontext
def remove_session(exception=None):
    SessionLocal.remove()

def get_user_info():
    user_info_str = request.headers.get('X-User-Info', '{}')
    try:
        user_info = ast.literal_eval(user_info_str)
        return user_info
    except:
        return {}

def get_product_info(product_id):
    try:
        response = requests.get(f"{PRODUCT_SERVICE_URL}/products/{product_id}", timeout=5)
        if response.status_code == 200:
            return response.json()
        return None
    except Exception as e:
        app.logger.error(f"Error fetching product: {e}")
        return None

def adjust_product_stock(product_id, adjustment):
    try:
        response = requests.post(
            f"{PRODUCT_SERVICE_URL}/products/{product_id}/stock/adjust",
            json={'adjustment': adjustment},
            timeout=5
        )
        return response.status_code == 200, response.json()
    except Exception as e:
        app.logger.error(f"Error adjusting stock: {e}")
        return False, {'error': str(e)}


@app.route('/orders', methods=['POST'])
def create_order():
    db = get_db()
    try:
        data = request.get_json()
        user_info = get_user_info()
        
        if 'product_id' not in data or 'quantity' not in data:
            return jsonify({'error': 'product_id and quantity are required'}), 400
        
        product_id = int(data['product_id'])
        quantity = int(data['quantity'])
        
        if quantity <= 0:
            return jsonify({'error': 'Quantity must be positive'}), 400
        
        product = get_product_info(product_id)
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        # check stock
        if product['stock'] < quantity:
            return jsonify({
                'error': 'Insufficient stock',
                'available': product['stock'],
                'requested': quantity
            }), 400
        
        total_price = product['price'] * quantity
        
        order = Order(
            user_id=user_info.get('user_id', 'anonymous'),
            username=user_info.get('username', 'anonymous'),
            product_id=product_id,
            product_name=product['name'],
            quantity=quantity,
            price_per_unit=product['price'],
            total_price=total_price,
            order_type=OrderType.BUY,
            status=OrderStatus.PENDING
        )
        
        db.add(order)
        db.commit()
        
        # decrease stock
        success, result = adjust_product_stock(product_id, -quantity)
        
        if success:
            order.status = OrderStatus.COMPLETED
            db.commit()
            db.refresh(order)
            
            return jsonify({
                'message': 'Order created successfully',
                'order': order.to_dict()
            }), 201
        else:
            order.status = OrderStatus.FAILED
            db.commit()
            
            return jsonify({
                'error': 'Failed to adjust stock',
                'order': order.to_dict(),
                'details': result
            }), 500
            
    except Exception as e:
        db.rollback()
        app.logger.error(f"Error creating order: {e}")
        return jsonify({'error': 'Failed to create order', 'details': str(e)}), 500

@app.route('/sell', methods=['POST'])
def sell_product():
    db = get_db()
    try:
        data = request.get_json()
        user_info = get_user_info()
        
        # validate
        if 'product_id' not in data or 'quantity' not in data:
            return jsonify({'error': 'product_id and quantity are required'}), 400
        
        product_id = int(data['product_id'])
        quantity = int(data['quantity'])
        
        if quantity <= 0:
            return jsonify({'error': 'Quantity must be positive'}), 400
        
        # prod info
        product = get_product_info(product_id)
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        # here is the ideea we can sell with 0.8 of original price
        buyback_price = product['price'] * 0.8
        total_price = buyback_price * quantity
        
        order = Order(
            user_id=user_info.get('user_id', 'anonymous'),
            username=user_info.get('username', 'anonymous'),
            product_id=product_id,
            product_name=product['name'],
            quantity=quantity,
            price_per_unit=buyback_price,
            total_price=total_price,
            order_type=OrderType.SELL,
            status=OrderStatus.PENDING
        )
        
        db.add(order)
        db.commit()
        
        # increase stock
        success, result = adjust_product_stock(product_id, quantity)
        
        if success:
            order.status = OrderStatus.COMPLETED
            db.commit()
            db.refresh(order)
            
            return jsonify({
                'message': 'Sell order created successfully',
                'order': order.to_dict(),
                'info': 'Shop buys back at 80% of original price'
            }), 201
        else:
            order.status = OrderStatus.FAILED
            db.commit()
            
            return jsonify({
                'error': 'Failed to adjust stock',
                'order': order.to_dict(),
                'details': result
            }), 500
            
    except Exception as e:
        db.rollback()
        app.logger.error(f"Error creating sell order: {e}")
        return jsonify({'error': 'Failed to create sell order', 'details': str(e)}), 500

@app.route('/orders/<int:order_id>', methods=['GET'])
def get_order(order_id):
    db = get_db()
    try:
        user_info = get_user_info()
        
        order = db.query(Order).filter(Order.id == order_id).first()
        if not order:
            return jsonify({'error': 'Order not found'}), 404
        
        if 'admin' not in user_info.get('roles', []):
            if order.user_id != user_info.get('user_id'):
                return jsonify({'error': 'Unauthorized'}), 403
        
        return jsonify(order.to_dict())
    except Exception as e:
        app.logger.error(f"Error fetching order: {e}")
        return jsonify({'error': 'Database error'}), 500

@app.route('/orders/user/<user_id>', methods=['GET'])
def get_user_orders(user_id):
    db = get_db()
    try:
        user_info = get_user_info()
        
        if user_id != user_info.get('user_id') and 'admin' not in user_info.get('roles', []):
            return jsonify({'error': 'Unauthorized'}), 403
        
        orders = db.query(Order).filter(Order.user_id == user_id).order_by(Order.created_at.desc()).all()
        
        return jsonify({
            'orders': [o.to_dict() for o in orders],
            'count': len(orders)
        })
    except Exception as e:
        app.logger.error(f"Error fetching user orders: {e}")
        return jsonify({'error': 'Database error'}), 500

@app.route('/orders', methods=['GET'])
def get_all_orders():
    db = get_db()
    try:
        user_info = get_user_info()
        
        if 'admin' not in user_info.get('roles', []):
            return jsonify({'error': 'Admin access required'}), 403
        
        query = db.query(Order)
        
        status = request.args.get('status')
        if status:
            try:
                status_enum = OrderStatus(status)
                query = query.filter(Order.status == status_enum)
            except ValueError:
                return jsonify({'error': f'Invalid status: {status}'}), 400
        
        order_type = request.args.get('type')
        if order_type:
            try:
                type_enum = OrderType(order_type)
                query = query.filter(Order.order_type == type_enum)
            except ValueError:
                return jsonify({'error': f'Invalid order type: {order_type}'}), 400
        
        orders = query.order_by(Order.created_at.desc()).all()
        
        return jsonify({
            'orders': [o.to_dict() for o in orders],
            'count': len(orders),
            'filters': {
                'status': status,
                'type': order_type
            }
        })
    except Exception as e:
        app.logger.error(f"Error fetching orders: {e}")
        return jsonify({'error': 'Database error'}), 500

## statistics
@app.route('/orders/stats', methods=['GET'])
def get_order_stats():
    db = get_db()
    try:
        user_info = get_user_info()
        
        # only admin
        if 'admin' not in user_info.get('roles', []):
            return jsonify({'error': 'Admin access required'}), 403
        
        total_orders = db.query(Order).count()
        buy_orders = db.query(Order).filter(Order.order_type == OrderType.BUY).count()
        sell_orders = db.query(Order).filter(Order.order_type == OrderType.SELL).count()
        
        completed_orders = db.query(Order).filter(Order.status == OrderStatus.COMPLETED).count()
        pending_orders = db.query(Order).filter(Order.status == OrderStatus.PENDING).count()
        failed_orders = db.query(Order).filter(Order.status == OrderStatus.FAILED).count()
        
        buy_revenue = db.query(Order).filter(
            Order.order_type == OrderType.BUY,
            Order.status == OrderStatus.COMPLETED
        ).with_entities(Order.total_price).all()
        total_revenue = sum([order[0] for order in buy_revenue])
        
        return jsonify({
            'total_orders': total_orders,
            'by_type': {
                'buy': buy_orders,
                'sell': sell_orders
            },
            'by_status': {
                'completed': completed_orders,
                'pending': pending_orders,
                'failed': failed_orders
            },
            'revenue': {
                'total': round(total_revenue, 2),
                'currency': 'RON'
            }
        })
    except Exception as e:
        app.logger.error(f"Error calculating stats: {e}")
        return jsonify({'error': 'Database error'}), 500


@app.route('/health')
def health():
    db = get_db()
    try:
        db.execute('SELECT 1')
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.utcnow().isoformat(),
            'service': 'order-service',
            'database': 'connected'
        })
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'timestamp': datetime.utcnow().isoformat(),
            'service': 'order-service',
            'database': 'disconnected',
            'error': str(e)
        }), 503

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002, debug=True)

